package com.primeiroprojweb.sping.web.mvc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpingWebMvcApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpingWebMvcApplication.class, args);
	}

}
