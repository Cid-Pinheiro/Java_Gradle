package com.primeiroprojweb.sping.web.mvc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpingWebMvcApplicationTests {

	@Test
	void contextLoads() {
	}

}
